package saarland.cispa.trackerlib;

import java.net.URL;

public class TrackerLib implements BeaconConsumer {

    URL serverUrl;

    public TrackerLib() {
    }
}
