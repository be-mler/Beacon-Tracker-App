# ble-trackback

Android application collecting data from BLE Beacons