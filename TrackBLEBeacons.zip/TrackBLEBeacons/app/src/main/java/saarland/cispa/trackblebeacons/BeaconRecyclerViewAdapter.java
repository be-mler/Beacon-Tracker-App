package saarland.cispa.trackblebeacons;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.card.MaterialCardView;

import java.sql.Date;
import java.text.DateFormat;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import saarland.cispa.bletrackerlib.data.SimpleBeacon;
import saarland.cispa.trackblebeacons.helpers.CountHelper;

import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.ALTBEACON_LAYOUT;
import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.EDDYSTONE_TLM_LAYOUT;
import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.EDDYSTONE_UID_LAYOUT;
import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.EDDYSTONE_URL_LAYOUT;
import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.IBEACON_LAYOUT;
import static saarland.cispa.bletrackerlib.data.SimpleBeaconParser.RUUVI_LAYOUT;


public class BeaconRecyclerViewAdapter extends ListAdapter<SimpleBeacon, BeaconRecyclerViewAdapter.BaseHolder> {

    private OnControlsOpen onControlsOpen;
    private Context context;
    public static final DiffUtil.ItemCallback<SimpleBeacon> DIFF_CALLBACK = new DiffUtil.ItemCallback<SimpleBeacon>() {
        @Override
        public boolean areItemsTheSame(@NonNull SimpleBeacon oldItem, @NonNull SimpleBeacon newItem) {
            return oldItem.hashCode() == newItem.hashCode();
        }

        @Override
        public boolean areContentsTheSame(@NonNull SimpleBeacon oldItem, @NonNull SimpleBeacon newItem) {
            return oldItem == newItem;
        }
    };


    public BeaconRecyclerViewAdapter(Context context, OnControlsOpen onControlsOpen) {
        super(DIFF_CALLBACK);

        this.context = context;
        this.onControlsOpen = onControlsOpen;
    }

    @NonNull
    @Override
    public BaseHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.beacon_item, parent, false);

        switch (viewType) {
            case R.layout.eddystone_uid_item: return new EddystoneUidHolder(view);
            case R.layout.eddystone_url_item: return new EddystoneUrlHolder(view);
            case R.layout.ruuvitag_item: return new RuuviTagHolder(view);
            case R.layout.ibeacon_altbeacon_item: return new AltBeaconIbeaconHolder(view);
            default: return new BaseHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BaseHolder holder, int position) {
        SimpleBeacon beacon = getItem(position);

        holder.bindView(beacon);
    }

    @Override
    public int getItemViewType(int position) {
        String beaconType = getItem(position).getType();

        if (EDDYSTONE_UID_LAYOUT.getIdentifier().equals(beaconType)) {
            return R.layout.eddystone_uid_item;
        } else if (EDDYSTONE_URL_LAYOUT.getIdentifier().equals(beaconType)) {
            return R.layout.eddystone_url_item;
        } else if (RUUVI_LAYOUT.getIdentifier().equals(beaconType)) {
            return R.layout.ruuvitag_item;
        } else if (ALTBEACON_LAYOUT.getIdentifier().equals(beaconType) || IBEACON_LAYOUT.getIdentifier().equals(beaconType)) {
            return R.layout.ibeacon_altbeacon_item;
        } else {
            return R.layout.ibeacon_altbeacon_item;
        }
    }

    static class BaseHolder extends RecyclerView.ViewHolder {

        public Button visit_website_btn;
        public Button ruuvi_visit_website_button;
        public MaterialCardView card;
        public TextView address;
        public TextView distance;
        public TextView manufacturer;
        public TextView last_seen;
        public TextView rssid;
        public TextView tx;

        public TextView battery;
        public TextView temperature;
        public TextView uptime;
        public TextView pdu_sent;

        public BaseHolder(@NonNull View itemView) {
            super(itemView);

            visit_website_btn = itemView.findViewById(R.id.visit_website_btn);
            ruuvi_visit_website_button = itemView.findViewById(R.id.ruuvi_visit_website_btn);
            card = itemView.findViewById(R.id.card);
            address = itemView.findViewById(R.id.address);
            distance = itemView.findViewById(R.id.distance);
            manufacturer = itemView.findViewById(R.id.manufacturer);
            last_seen = itemView.findViewById(R.id.last_seen);
            rssid = itemView.findViewById(R.id.rssi);
            address = itemView.findViewById(R.id.tx);

            battery = itemView.findViewById(R.id.battery);
            temperature = itemView.findViewById(R.id.temperature);
            uptime = itemView.findViewById(R.id.uptime);
            pdu_sent = itemView.findViewById(R.id.pdu_sent);
        }


        public void bindView(SimpleBeacon beacon) {
            visit_website_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onUrlClicked();
                }
            });
            ruuvi_visit_website_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onUrlClicked();
                }
            });
            card.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return false;
                }
            });
            address.setText(beacon.getBluetoothAddress());
            distance.setText(String.format(Locale.getDefault(), "%.2f", beacon.getDistance()));

            manufacturer.setText(String.format(Locale.getDefault(), "0x%04X", beacon.getManufacturer()));

            last_seen.setText(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.getDefault()).format(Date.valueOf(beacon.getDiscoveryTime())));

            rssid.setText(String.format(itemView.getContext().getString(R.string.rssi_x_dbm), beacon.getSignalStrength()));

            address.setText(String.format(itemView.getContext().getString(R.string.tx_x_dbm), beacon.getTransmitterPower()));

            LinearLayout[] telemtryContainers = {itemView.findViewById(R.id.battery_container),
                                                 itemView.findViewById(R.id.temperature_container),
                                                 itemView.findViewById(R.id.uptime_container),
                                                 itemView.findViewById(R.id.pdu_sent_container)};
            if (EDDYSTONE_TLM_LAYOUT.getIdentifier().equals(beacon.getType())) {
                for (LinearLayout telemtryContainer : telemtryContainers) {
                    telemtryContainer.setVisibility(View.VISIBLE);
                }
                battery.setText(String.format(itemView.getContext().getString(R.string.battery_x_mv), beacon.getBatteryMilliVolts()));

                temperature.setText(String.format(itemView.getContext().getString(R.string.temperature_x_degres), beacon.getTemperature()));

                uptime.setText(String.format(itemView.getContext().getString(R.string.uptime_x_seconds), CountHelper.coolFormat(beacon.getUptime(), 0)));

                pdu_sent.setText(String.format(itemView.getContext().getString(R.string.x_packets_sent), CountHelper.coolFormat(beacon.getPduCount(), 0)));
            } else {
                for (LinearLayout telemetryContainer : telemtryContainers) {
                    telemetryContainer.setVisibility(View.GONE);
                }
            }
        }

        public void hideAllLayouts() {
            itemView.findViewById(R.id.ibeacon_altbeacon_item).setVisibility(View.GONE);
            itemView.findViewById(R.id.eddystone_uid_item).setVisibility(View.GONE);
            itemView.findViewById(R.id.eddystone_url_item).setVisibility(View.GONE);
            itemView.findViewById(R.id.ruuvitag_item).setVisibility(View.GONE);
        }

        private void onUrlClicked() {
            //TODO: OpenURL
        }
    }

    static class AltBeaconIbeaconHolder extends BaseHolder {

        public TextView beacon_type;
        public TextView url;
        public TextView proximity_uuid;
        public TextView major;
        public TextView minor;

        public AltBeaconIbeaconHolder(@NonNull View itemView) {
            super(itemView);

            beacon_type = itemView.findViewById(R.id.beacon_type);
            proximity_uuid = itemView.findViewById(R.id.proximity_uuid);
            major = itemView.findViewById(R.id.major);
            minor = itemView.findViewById(R.id.minor);
        }

        @Override
        public void bindView(SimpleBeacon beacon) {
            super.bindView(beacon);

            card.setCardBackgroundColor(ContextCompat.getColor(itemView.getContext(), R.color.ibeaconBackground));
            hideAllLayouts();

            itemView.findViewById(R.id.ibeacon_altbeacon_item).setVisibility(View.VISIBLE);

            beacon_type.setText(String.format(Locale.getDefault(), "%s",
            (IBEACON_LAYOUT.getIdentifier().equals(beacon.getType()) ? itemView.getContext().getString(R.string.ibeacon) : itemView.getContext().getString(R.string.altbeacon))));

            proximity_uuid.setText(String.format(itemView.getContext().getString(R.string.uuid_x), beacon.getUuid()));
            major.setText(String.format(itemView.getContext().getString(R.string.major_x), beacon.getMajor()));
            minor.setText(String.format(itemView.getContext().getString(R.string.minor_x), beacon.getMajor()));
        }
    }

    static class EddystoneUidHolder extends BaseHolder {

        public TextView beacon_type;
        public TextView namespace_id;
        public TextView instance_id;

        public EddystoneUidHolder(@NonNull View itemView) {
            super(itemView);

            beacon_type = itemView.findViewById(R.id.beacon_type);
            namespace_id = itemView.findViewById(R.id.namespace_id);
            instance_id = itemView.findViewById(R.id.instance_id);
        }

        @Override
        public void bindView(SimpleBeacon beacon) {
            super.bindView(beacon);

            card.setCardBackgroundColor(ContextCompat.getColor(itemView.getContext(), R.color.eddystoneUidBackground));
            hideAllLayouts();

            itemView.findViewById(R.id.eddystone_uid_item).setVisibility(View.VISIBLE);

            beacon_type.setText(String.format(Locale.getDefault(), "%s%s",
                    itemView.getContext().getString(R.string.eddystone_uid),
            (beacon.isHasTelemetry() ? itemView.getContext().getString(R.string.plus_tlm) : "")));

            namespace_id.setText(String.format(itemView.getContext().getString(R.string.namespace_id_x), beacon.getNamespaceId()));

            instance_id.setText(String.format(itemView.getContext().getString(R.string.instance_id_x), beacon.getInstanceId()));
        }
    }

    static class EddystoneUrlHolder extends BaseHolder {

        public TextView beacon_type;
        public TextView url;

        public EddystoneUrlHolder(@NonNull View itemView) {
            super(itemView);

            beacon_type = itemView.findViewById(R.id.beacon_type);
            url = itemView.findViewById(R.id.url);
        }

        @Override
        public void bindView(SimpleBeacon beacon) {
            super.bindView(beacon);

            card.setCardBackgroundColor(ContextCompat.getColor(itemView.getContext(), R.color.eddystoneUrlBackground));
            hideAllLayouts();

            itemView.findViewById(R.id.eddystone_url_item).setVisibility(View.VISIBLE);


            beacon_type.setText(String.format(Locale.getDefault(), "%s%s",
                    itemView.getContext().getString(R.string.eddystone_url),
            (beacon.isHasTelemetry() ? itemView.getContext().getString(R.string.plus_tlm) : "")));

            url.setText(String.format(itemView.getContext().getString(R.string.url_x), beacon.getUrl()));
        }
    }

    static class RuuviTagHolder extends BaseHolder {

        public TextView beacon_type;
        public TextView ruuvi_url;
        public TextView ruuvi_air_pressure;
        public TextView ruuvi_temperature;
        public TextView ruuvi_humidity;

        public RuuviTagHolder(@NonNull View itemView) {
            super(itemView);

            beacon_type = itemView.findViewById(R.id.beacon_type);
            ruuvi_url = itemView.findViewById(R.id.ruuvi_url);
            ruuvi_air_pressure = itemView.findViewById(R.id.ruuvi_air_pressure);
            ruuvi_temperature = itemView.findViewById(R.id.ruuvi_temperature);
            ruuvi_humidity = itemView.findViewById(R.id.ruuvi_humidity);
        }

        @Override
        public void bindView(SimpleBeacon beacon) {
            super.bindView(beacon);

            card.setCardBackgroundColor(ContextCompat.getColor(itemView.getContext(), R.color.ruuvitagBackground));
            hideAllLayouts();

            itemView.findViewById(R.id.ruuvitag_item).setVisibility(View.VISIBLE);

            beacon_type.setText(String.format(Locale.getDefault(), "%s", itemView.getContext().getString(R.string.ruuvitag)));

            ruuvi_url.setText(String.format(itemView.getContext().getString(R.string.url_x), beacon.getUrl()));

            ruuvi_air_pressure.setText(String.format(itemView.getContext().getString(R.string.air_pressure_x_hpa), beacon.getAirPressure()));
            ruuvi_temperature.setText(String.format(itemView.getContext().getString(R.string.temperature_d_degres), beacon.getTemperature()));
            ruuvi_humidity.setText(String.format(itemView.getContext().getString(R.string.humidity_x_percent), beacon.getHumidity()));
        }
    }


    public interface OnControlsOpen {
        void onControlsOpen(SimpleBeacon beacon);
    }
}
